const jobList = [
    {   
        id:'1',
        jobName: '销售经理',
        address:'广州',
        exp:'1-3年',
        degree:'大专',
        salary:'10K-20K',
        time:'1天前发布'
    },
    {   
        id:'2',
        jobName: '客户经理',
        address: '杭州',
        exp: '1-3年',
        degree: '大专',
        salary: '8K-16K',
        time: '2天前发布'
    },
    {   
        id:'3',
        jobName: '测试开发专家',
        address: '杭州',
        exp: '5-10年',
        degree: '本科',
        salary: '28K-40K',
        time: '1天前发布'
    },
    {   
        id:'4',
        jobName: '销售总监',
        address: '北京',
        exp: '经验不限',
        degree: '本科',
        salary: '35K-50K',
        time: '1天前发布'
    },
    {   
        id:'5',
        jobName: '前端开发工程师',
        address: '深圳',
        exp: '1-3年',
        degree: '本科',
        salary: '15K-30K',
        time: '3天前发布'
    },
    {   
        id:'6',
        jobName: '前端开发校招生',
        address: '杭州',
        exp: '应届毕业生',
        degree: '本科',
        salary: '10K-20K',
        time: '1天前发布'
    },
    {
        id: '6',
        jobName: '产品经理',
        address: '深圳',
        exp: '1-3年',
        degree: '本科',
        salary: '20-40K',
        time: '1天前发布'
    },
    {
        id: '6',
        jobName: '前端开发校招生',
        address: '杭州',
        exp: '应届毕业生',
        degree: '本科',
        salary: '10K-20K',
        time: '1天前发布'
    },
    {
        id: '6',
        jobName: 'Java开发校招生',
        address: '杭州',
        exp: '应届毕业生',
        degree: '本科',
        salary: '10K-20K',
        time: '1天前发布'
    },
    {
        id: '6',
        jobName: '前端开发校招生',
        address: '杭州',
        exp: '应届毕业生',
        degree: '本科',
        salary: '10K-20K',
        time: '1天前发布'
    },
]
export default jobList;