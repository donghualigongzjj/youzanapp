const address=[
    {   
        id:'0',
        latitude:'30.2751800000',
        longitude:'120.1261900000',
        shortAddress:'杭州市西湖区' ,
        detailAddress:'学院路77号黄龙万科中心G座18楼'
    },
    {
        id: '1',
        latitude: '39.9784510000',
        longitude: '116.4946210000',
        shortAddress: '北京市朝阳区',
        detailAddress: '恒通商务园B12楼D楼'
    },
    {
        id: '2',
        latitude: '22.5238990000',
        longitude: '113.9354930000',
        shortAddress: '深圳市南山区',
        detailAddress: '芒果网大厦11层'
    }
]
export default address