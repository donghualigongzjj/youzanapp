const jobList = [
    {
        id: 0,
        jobName: '前端开发工程师',
        address: '深圳',
        salary: '15K-30K',
        time: '1天前发布',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 1,
        jobName: '前端开发工程师',
        address: '深圳',
        salary: '15K-30K',
        time: '1天前发布',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 2,
        jobName: '小程序开发工程师',
        address: '杭州',
        time: '1天前发布',
        salary: '10K-20K',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '杭州市西湖区学院路77号黄龙万科中心G座18层',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 3,
        jobName: '资深Java开发工程师',
        address: '北京',
        salary: '30K-50K',
        time: '2天前发布',
        exp: '5-10年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 4,
        jobName: '前端开发工程师',
        address: '深圳',
        salary: '15K-30K',
        time: '1天前发布',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 5,
        jobName: '前端开发工程师',
        address: '深圳',
        salary: '15K-30K',
        time: '1天前发布',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 6,
        jobName: '前端开发工程师',
        address: '深圳',
        salary: '15K-30K',
        time: '1天前发布',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },
    {
        id: 7,
        jobName: '前端开发工程师',
        address: '深圳',
        time: '1天前发布',
        salary: '15K-30K',
        exp: '1-3年',
        degree: '本科',
        shortdec: '职位诱惑：牛人多,工程师文化,创业氛围浓',
        detailAddress: '深圳市南山区后海大道2378号芒果网大厦11楼',
        similarJob: {
            id: '',
            jobName: '',
            address: '',
            exp: '',
            degree: '',
            salary: '',
            time: ''
        }
    },   
]
export default jobList